# gui frontend for CFG simplifier
import streamlit as st
import ast
def remove_unit(CFG):
    single_terminals = []
    for i in CFG:
        if len(CFG[i])==1 and CFG[i][0].islower():
            single_terminals.append(i)
    st.write("Single Terminals are : ",single_terminals)
    # Now, checking if any of the single terminals are in RHS of any other state
    while True:
        changed = False
        for i in CFG:
            for j in CFG[i]:
                for l in j:
                    if l in single_terminals:
                        k = single_terminals.index(l)
                        CFG[i].append(j.replace(single_terminals[k], CFG[single_terminals[k]][0]))
                        CFG[i].remove(j)
                        if len(CFG[i])==1:
                            single_terminals.append(i)
                        st.write("Single Terminals are : ",single_terminals)
                        changed = True
        if not changed:
            break
    print(CFG)
    return CFG

def remove_useless(CFG):
    reachable_states = []
    given_states = []
    terminals = []
    for i in CFG:
        if i not in given_states:
            given_states.append(i)
        for j in CFG[i]:
            for l in j:
                if l not in reachable_states:
                    if l.isupper():
                        reachable_states.append(l)
                    else:
                        terminals.append(l)
    st.write("Reachable states are : ", reachable_states)
    # st.write(given_states)
    st.write("Terminals states are : ",terminals)
    unreachable = []
    for i in given_states:
        if i=="S":
            continue
        elif i not in reachable_states:
            unreachable.append(i)
    st.write("Unreachable states are ", unreachable)
    for i in unreachable:
        CFG.pop(i)
    st.write(CFG)
    return CFG

def remove_null(CFG):
    # Find nullable non-terminals
    nullable = set()
    for nonterm in CFG:
        if '' in CFG[nonterm]:
            nullable.add(nonterm)
            st.write("Nullable found i.e. : ", nonterm)
    while True:
        new_nullable = set()
        for nonterm, prods in CFG.items():
            for prod in prods:
                if all(s in nullable for s in prod):
                    new_nullable.add(nonterm)
                    break
        if new_nullable == nullable:
            break
        nullable = new_nullable
    
    # Construct new productions
    new_prods = {}
    for nonterm, prods in CFG.items():
        new_prods[nonterm] = set()
        for prod in prods:
            new_prod = ['']
            for s in prod:
                if s in nullable:
                    new_prod += [x + s for x in new_prod]
                else:
                    new_prod = [x + s for x in new_prod]
            new_prods[nonterm] |= set(new_prod)
    
    # Now Remove epsilon productions and return the new CFG
    new_CFG = {}
    for nonterm, prods in new_prods.items():
        new_CFG[nonterm] = set()
        for prod in prods:
            if prod != '':
                new_CFG[nonterm].add(prod)
    return new_CFG

st.title("CFG Simplifier")
st.subheader("Enter the CFG in the following format:")
st.write("S->aS|bS|c")
st.write("A->aA|bA|c")
st.write("B->aB|bB|c")
st.write("C->aC|bC|c")

data = st.text_area("Enter CFG here")
print(data)
data = data.split('\n')
CFG = {}
for i in data:
    print(i)
    var = i[0]
    j = i.split(' | ')
    t = 1
    CFG[var] = []
    CFG[var].append(j[0].split(" → ")[1])
    if len(j) > 1:
        while (t < len(j)):
            CFG[var].append(j[t])
            t += 1
st.write(CFG)

from graphviz import Digraph

def plot_cfg(cfg):
    dot = Digraph(format='png')

    dot.node('S', shape='circle')
    
    dot.node('D0', shape='doublecircle')

    for lhs in cfg:
        for rhs in cfg[lhs]:
            if len(rhs) == 1:  
                dot.edge(lhs, 'D0', label=rhs)
            else:  
                dot.edge(lhs, rhs[1], label=rhs[0])
    
    dot.render('cfg', view=True)

def generate_new_var(cfg, mfg):
    # generate new variable for first two symbols
    variablejar = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    # pop used variables for the variablejar
    for i in cfg:
        if i in variablejar:
            variablejar.remove(i)
    for i in mfg:
        if i in variablejar:
            variablejar.remove(i)
    newvar = variablejar.pop(0)
    return newvar

def remove_long(CFG):
    MFG = {}
    
    for nonterm, prods in CFG.items():
        for prod in prods:
            if len(prod) > 2:
                newVar = generate_new_var(CFG, MFG)
                st.write("Setting", newVar, "->", prod[0:2])
                
                MFG[newVar] = [prod[0:2]]
                MFG[nonterm] = [newVar+prod[2:]]
                st.write("Reseting (", nonterm, "-> ",prod,") to ",nonterm," -> ", newVar+prod[2:])
            else:
                if nonterm in MFG:
                    MFG[nonterm].append(prod)
                else:
                    MFG[nonterm] = [prod]                
    print(MFG)
    return MFG

def checker(cfg):
    for i in cfg:
        for j in cfg[i]:
            if j.islower() and len(j)==1:
                continue
            elif j.isupper() and len(j)==2:
                continue
            else:
                return False
    return True

def cfg_to_cnf(cfg):
    # we will start by Eliminate terminals from the RHS of the production if they exist with other non-terminals or terminals
    # In the production rule S0 → aA | Aa, S → aA | Aa, A → aBB and B → Aa, terminal a exists on RHS with non-terminals. So we will replace terminal a with X
    simple = cfg.copy()
    dimple = {}
    print(type(simple))
    variablejar = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    # pop used variables for the variablejar
    for i in cfg:
        if i in variablejar:
            variablejar.remove(i)
    # find mixed productions
    mixed = []
    for i in cfg:
        for j in cfg[i]:
            if (len(j)>1):
                s1 = sorted(j)
                if s1[0].isupper() and s1[len(s1)-1].islower():
                    mixed.append(j)
    st.write("Mixed Productions are",mixed)
    mapped_terminal = {}
    for key , prods in simple.items():
            for prod1 in prods:
                # prod = ''.join(sorted(prod1))
                print(prod1)
                if prod1 in mixed:
                    # find terminal symbol and map it to a new variable
                    # add that new mapping to the CFG
                    # replace the terminal symbol with the new variable
                    for i in prod1:
                        if i.islower():
                            st.write(i, "is Terminal in -", prod1)
                            newvar = variablejar.pop(0)
                            if (i not in mapped_terminal):
                                mapped_terminal[i] = newvar
                            else:
                                newvar = mapped_terminal[i]
                            tem_prods = simple[key].copy()
                            tem_prods.remove(prod1)
                            tobeadded  = prod1.replace(i, newvar)
                            st.write("replace", i, "with", newvar, "in", prod1, "to get", tobeadded)
                            tem_prods.append(tobeadded)
                            # st.write(tem_prods)
                            if key in dimple:
                                print(dimple[key])
                                dimple[key].append(tobeadded)
                            else:
                                dimple[key] = [tobeadded]
                            if newvar in dimple:
                                dimple[newvar].append(i)
                            dimple[newvar] = [i]
                else:
                    if key in dimple:
                        dimple[key].append(prod1)
                    else:
                        dimple[key] = [prod1]
    print(dimple)
    return dimple

option = st.radio("Select an option",("Plot CFG", "Check CNF"))
if st.button("Simplify CFG"):
    CFG1 = remove_unit(CFG)
    CFG2 = remove_useless(CFG1)
    CFG3 = remove_null(CFG2)
    for nonterm, prods in CFG3.items():
        CFG3[nonterm] = list(prods)
    st.write(CFG3)
    if ( option == "Plot CFG"):
        st.title("Plotting CFG3")
        plot_cfg(CFG3)
    else:
        if (checker(CFG3)):
            st.title("Already in CNF Normal Form")
        else:
            CFG4 = cfg_to_cnf(CFG3)
            cfg4 = remove_long(CFG4)
            while (not checker(cfg4)):
                cfg4 = remove_long(cfg4)
            st.title("Final CNF Conversion is: \n")
            st.write(cfg4)